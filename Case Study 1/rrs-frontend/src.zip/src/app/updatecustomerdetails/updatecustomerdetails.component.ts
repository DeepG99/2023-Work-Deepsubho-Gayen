import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updatecustomerdetails',
  templateUrl: './updatecustomerdetails.component.html',
  styleUrls: ['./updatecustomerdetails.component.css']
})
export class UpdatecustomerdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
