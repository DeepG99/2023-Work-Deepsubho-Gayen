import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deletecustomer',
  templateUrl: './deletecustomer.component.html',
  styleUrls: ['./deletecustomer.component.css']
})
export class DeletecustomerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
