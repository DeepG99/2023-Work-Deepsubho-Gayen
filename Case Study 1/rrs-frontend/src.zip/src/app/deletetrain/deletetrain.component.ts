import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deletetrain',
  templateUrl: './deletetrain.component.html',
  styleUrls: ['./deletetrain.component.css']
})
export class DeletetrainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
