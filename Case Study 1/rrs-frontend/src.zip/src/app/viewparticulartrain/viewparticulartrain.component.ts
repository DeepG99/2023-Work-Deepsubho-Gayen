import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewparticulartrain',
  templateUrl: './viewparticulartrain.component.html',
  styleUrls: ['./viewparticulartrain.component.css']
})
export class ViewparticulartrainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
