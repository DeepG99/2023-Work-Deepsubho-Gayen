import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-changeparticulartraindetails',
  templateUrl: './changeparticulartraindetails.component.html',
  styleUrls: ['./changeparticulartraindetails.component.css']
})
export class ChangeparticulartraindetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
