import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewbookings',
  templateUrl: './viewbookings.component.html',
  styleUrls: ['./viewbookings.component.css']
})
export class ViewbookingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
