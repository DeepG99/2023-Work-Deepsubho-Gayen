export class User{
    username = '';
    password = '';
}