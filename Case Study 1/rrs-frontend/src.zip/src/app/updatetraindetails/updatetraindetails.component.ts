import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updatetraindetails',
  templateUrl: './updatetraindetails.component.html',
  styleUrls: ['./updatetraindetails.component.css']
})
export class UpdatetraindetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
