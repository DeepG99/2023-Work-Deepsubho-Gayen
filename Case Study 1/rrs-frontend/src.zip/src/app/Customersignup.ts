export class Customersignup{
    Name = '';
    Age = '';
    Gender = '';
    Email = '';
    Password = '';
}