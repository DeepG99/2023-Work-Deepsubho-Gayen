export class Train {
    id?: number;
    name = "";
    sourceStation = "";
    destinationStation = "";
    arrivalDatetime = "";
    departureDatetime = "";
    totalSeats = "";
    availableSeats = "";
    class = "";
    fare = "";
}