export class Reservation {
    id?: number;
    trainno = "";
    customerId = "";
    noOfPeople = "";
    sourceStation = "";
    destinationStation = "";
    datetimeOfCreation = "";
    status = "";
}