export class Payment {
    id?: number;
    amount = "";
    customerId = "";
    reservationId = "";
}