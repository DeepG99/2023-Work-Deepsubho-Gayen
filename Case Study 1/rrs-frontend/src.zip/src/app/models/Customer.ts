export class Customer {
    customerId?: number;
    name = "";
    age = "";
    gender = "";
    email = "";
    password = "";
}