export class LoginDetails{
    Email:   string = '';
    Password:   string = '';

}