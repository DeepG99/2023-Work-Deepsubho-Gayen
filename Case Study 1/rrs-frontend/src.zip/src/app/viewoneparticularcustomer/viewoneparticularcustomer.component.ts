import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewoneparticularcustomer',
  templateUrl: './viewoneparticularcustomer.component.html',
  styleUrls: ['./viewoneparticularcustomer.component.css']
})
export class ViewoneparticularcustomerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
