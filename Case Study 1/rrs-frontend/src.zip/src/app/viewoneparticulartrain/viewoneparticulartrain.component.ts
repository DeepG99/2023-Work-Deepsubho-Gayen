import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewoneparticulartrain',
  templateUrl: './viewoneparticulartrain.component.html',
  styleUrls: ['./viewoneparticulartrain.component.css']
})
export class ViewoneparticulartrainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
