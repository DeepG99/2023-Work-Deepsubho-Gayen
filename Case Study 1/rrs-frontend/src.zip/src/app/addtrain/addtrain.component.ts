import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addtrain',
  templateUrl: './addtrain.component.html',
  styleUrls: ['./addtrain.component.css']
})
export class AddtrainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
