import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-searchtrains',
  templateUrl: './searchtrains.component.html',
  styleUrls: ['./searchtrains.component.css']
})
export class SearchtrainsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
