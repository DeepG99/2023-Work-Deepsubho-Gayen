import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewparticularcustomer',
  templateUrl: './viewparticularcustomer.component.html',
  styleUrls: ['./viewparticularcustomer.component.css']
})
export class ViewparticularcustomerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
