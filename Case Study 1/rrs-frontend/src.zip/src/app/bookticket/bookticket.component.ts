import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookticket',
  templateUrl: './bookticket.component.html',
  styleUrls: ['./bookticket.component.css']
})
export class BookticketComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
